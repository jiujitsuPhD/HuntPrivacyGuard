# Firefox build

This folder contains the Firefox version of Hunt's Privacy Guard, based on the Chrome extension in the parent folder.

## Load for testing

1. Open `about:debugging` in Firefox.
2. Select **This Firefox**.
3. Select **Load Temporary Add-on…** and choose this folder's `manifest.json`.

Firefox 140 or newer is required on desktop. Firefox for Android 142 or newer is required. The extension uses Manifest V3 event-page background scripts and Firefox's `storage.session` API.

