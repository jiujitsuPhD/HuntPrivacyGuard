(() => {
  if (window.__privacyGuardInstalled || !globalThis.PrivacyGuardEngine) return;
  window.__privacyGuardInstalled = true;

  const DEFAULT_TERMS = [];
  let settings = { protectedTerms: DEFAULT_TERMS, enabled: true, policy: "block" };
  const approvedForms = new WeakSet();
  const FIELD_SELECTOR = [
    "textarea",
    'input:not([type]), input[type="text"], input[type="search"], input[type="email"], input[type="url"], input[type="tel"]',
    '[contenteditable]:not([contenteditable="false"])',
    '[role="textbox"]'
  ].join(",");

  function updateFromStorage(values) {
    const terms = Array.isArray(values.protectedTerms)
      ? PrivacyGuardEngine.normalizeTerms(values.protectedTerms)
      : DEFAULT_TERMS;
    settings = {
      protectedTerms: terms,
      profiles: Array.isArray(values.profiles) ? values.profiles : undefined,
      enabled: values.protectionEnabled !== false,
      policy: values.policy === "warn" ? "warn" : "block"
    };
  }

  chrome.storage.local.get(
    { protectedTerms: DEFAULT_TERMS, profiles: null, protectionEnabled: true, policy: "block" },
    updateFromStorage
  );
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") return;
    const current = { ...settings };
    if (changes.protectedTerms) current.protectedTerms = changes.protectedTerms.newValue;
    if (changes.profiles) current.profiles = changes.profiles.newValue;
    if (changes.protectionEnabled) current.enabled = changes.protectionEnabled.newValue !== false;
    if (changes.policy) current.policy = changes.policy.newValue;
    updateFromStorage({
      protectedTerms: current.protectedTerms,
      profiles: current.profiles,
      protectionEnabled: current.enabled,
      policy: current.policy
    });
  });

  function getText(element) {
    if (!element) return "";
    if (element instanceof HTMLTextAreaElement || element instanceof HTMLInputElement) return element.value || "";
    return element.innerText || element.textContent || "";
  }

  function isVisibleField(element) {
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && !element.disabled && element.getAttribute("aria-hidden") !== "true";
  }

  function fieldsWithin(root) {
    if (!root) return [];
    const fields = [...root.querySelectorAll(FIELD_SELECTOR)];
    if (root.matches?.(FIELD_SELECTOR)) fields.unshift(root);
    return fields.filter(isVisibleField);
  }

  function fieldForAction(target) {
    const form = target.closest("form");
    if (form) {
      const fields = fieldsWithin(form);
      const nonempty = fields.filter(field => getText(field).trim());
      return nonempty.at(-1) || fields.at(-1) || null;
    }
    let container = target.parentElement;
    for (let depth = 0; container && depth < 5; depth++, container = container.parentElement) {
      const fields = fieldsWithin(container);
      const nonempty = fields.filter(field => getText(field).trim());
      if (nonempty.length) return nonempty.at(-1);
    }
    return null;
  }

  function showNotice(action, match) {
    let notice = document.getElementById("privacy-guard-warning");
    if (!notice) {
      notice = document.createElement("div");
      notice.id = "privacy-guard-warning";
      Object.assign(notice.style, {
        position: "fixed", top: "16px", right: "16px", zIndex: "2147483647",
        maxWidth: "360px", padding: "14px 18px", background: "#7f1d1d", color: "#fff",
        border: "2px solid #fecaca", borderRadius: "10px", boxShadow: "0 4px 18px rgba(0,0,0,0.3)",
        fontSize: "14px", lineHeight: "1.5", fontFamily: "Arial, sans-serif"
      });
      document.documentElement.appendChild(notice);
    }
    notice.textContent = action === "block"
      ? "This message was blocked because it contains a protected term. Please contact the person who manages this computer to find out why."
      : "Hunt's Privacy Guard found a protected term. Sending this may put personal information on the web. Review your message before sending.";
    notice.style.display = "block";
  }

  function check(text, event) {
    const decision = PrivacyGuardEngine.decide(text, settings);
    if (decision.action === "allow") return false;
    if (decision.action === "warn") {
      const confirmed = window.confirm("A protected term was found. Sending this may put personal information on the web. Are you sure you want to continue?");
      if (confirmed) {
        const form = event?.target instanceof Element ? event.target.closest("form") : null;
        if (form) {
          approvedForms.add(form);
          setTimeout(() => approvedForms.delete(form), 0);
        }
        return false;
      }
    }
    if (event) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
    }
    showNotice("block", decision.match);
    chrome.runtime.sendMessage({ type: "PRIVACY_GUARD_BLOCKED" }, () => void chrome.runtime.lastError);
    return true;
  }

  function composerForTarget(target) {
    if (!(target instanceof Element)) return null;
    return target.matches(FIELD_SELECTOR) ? target : target.closest(FIELD_SELECTOR);
  }

  function isSubmissionControl(target) {
    if (!(target instanceof Element)) return false;
    const control = target.closest('button, input[type="submit"], input[type="image"]');
    if (!control) return false;
    if (control.type === "submit" || control.type === "image") return true;
    const marker = [control.getAttribute("data-testid"), control.getAttribute("aria-label"), control.title,
      control.innerText, control.value].filter(Boolean).join(" ").toLowerCase();
    return marker.includes("send-button") || marker.includes("send message") || marker.trim() === "send" ||
      marker.includes("submit") || marker.includes("post");
  }

  document.addEventListener("keydown", event => {
    const composer = composerForTarget(event.target);
    if (event.key === "Enter" && !event.shiftKey && !event.isComposing && composer) {
      check(getText(composer), event);
    }
  }, true);

  document.addEventListener("click", event => {
    if (!isSubmissionControl(event.target)) return;
    const control = event.target.closest('button, input[type="submit"], input[type="image"]');
    if (control?.closest("form") && (control.type === "submit" || control.type === "image")) return;
    const field = fieldForAction(event.target);
    if (field) check(getText(field), event);
  }, true);

  document.addEventListener("submit", event => {
    if (!(event.target instanceof HTMLFormElement)) return;
    if (approvedForms.has(event.target)) {
      approvedForms.delete(event.target);
      return;
    }
    const fields = fieldsWithin(event.target);
    const field = fields.filter(item => getText(item).trim()).at(-1) || fields.at(-1);
    if (field) check(getText(field), event);
  }, true);

  console.info("Hunt's Privacy Guard loaded.");
})();
