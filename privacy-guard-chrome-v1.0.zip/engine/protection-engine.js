/* Pure protection rules shared by the Chrome and Firefox adapters. */
(function (root, factory) {
  const engine = factory();
  if (typeof module === "object" && module.exports) module.exports = engine;
  else root.PrivacyGuardEngine = engine;
})(typeof globalThis === "object" ? globalThis : this, function () {
  "use strict";

  function normalizeTerms(terms) {
    return Array.isArray(terms)
      ? terms.map(term => String(term ?? "").trim()).filter(Boolean)
      : [];
  }

  function profilesFrom(settings) {
    if (Array.isArray(settings?.profiles) && settings.profiles.length) {
      return settings.profiles.map((profile, index) => ({
        id: String(profile?.id ?? index),
        name: String(profile?.name ?? `Profile ${index + 1}`),
        terms: normalizeTerms(profile?.terms)
      }));
    }
    return [{ id: "default", name: "Default", terms: normalizeTerms(settings?.protectedTerms) }];
  }

  function detect(text, settings) {
    const searchable = String(text ?? "").toLocaleLowerCase();
    for (const profile of profilesFrom(settings)) {
      for (const term of profile.terms) {
        if (searchable.includes(term.toLocaleLowerCase())) {
          return { term, profileId: profile.id, profileName: profile.name };
        }
      }
    }
    return null;
  }

  function decide(text, settings = {}) {
    if (settings.enabled === false) return { action: "allow", match: null };
    const match = detect(text, settings);
    if (!match) return { action: "allow", match: null };
    const policy = settings.policy === "warn" ? "warn" : "block";
    return { action: policy, match };
  }

  return Object.freeze({ normalizeTerms, profilesFrom, detect, decide });
});
